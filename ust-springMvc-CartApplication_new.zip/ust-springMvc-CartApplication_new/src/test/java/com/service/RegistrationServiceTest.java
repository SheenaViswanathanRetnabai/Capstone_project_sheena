package com.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.model.UserRegistration;
import com.repository.UserRepository;
@SpringBootTest
class RegistrationServiceTest {
	@Autowired
	private UserRepository userRepository;
	private UserRegistration userRegistration;
	@BeforeEach
	void setUp() throws Exception {
		userRegistration = new UserRegistration("testuser11@gmail.com","TestUser","123","123","Trivandrum",908766,500);
	}
	


	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testSaveUser() {
		userRepository.save(userRegistration);
		UserRegistration retvuser = userRepository.findById(userRegistration.getUsername()).get();
	     assertEquals("testuser11@gmail.com", retvuser.getUsername());
	}
String email="testuser11@gmail.com";
	@Test
	void testGetuserName() {
		
		UserRegistration retvuser = userRepository.findByUsername(email);
	     assertEquals("TestUser", retvuser.getCustomerName());
	}

	@Test
	void testIsUserexists() {
		boolean retvuser = userRepository.existsById(userRegistration.getUsername());
		assertTrue(retvuser);
	}

}
