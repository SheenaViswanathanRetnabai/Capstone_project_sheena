package com.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.model.Product;
import com.repository.ProductRepository;
@SpringBootTest
class ProductServiceTest {
	

	@Autowired
	private ProductRepository productRepository;
	private Product product;
	@BeforeEach
	public void setUp() throws Exception {		
		product = new Product(3039,"Mobile stand",10,500);
	}

	@AfterEach
	public void tearDown() throws Exception {
		 
	}
	

	@Test
	public void testGetProducts() {
		List<Product> productList = (List<Product>) productRepository.findAll();
		assertTrue(productList.size()>0);

	}
	

	@Test
	public void testGetProduct() {
		Product retvProduct = productRepository.findById(product.getProductId()).get();
	    assertEquals(3039, retvProduct.getProductId());
	}

	@Test
	public void testSaveProduct() {
		 productRepository.save(product);
	     Product retvProduct = productRepository.findById(product.getProductId()).get();
	     assertEquals(3039, retvProduct.getProductId());
	}

	
	  @Test public void testDeleteProduct() { 
		  Product product = new Product(101,"Books",40,100); 
		  productRepository.save(product);
		  productRepository.deleteById(product.getProductId()); 
		  Optional<Product> optional = productRepository.findById(product.getProductId());
		  assertEquals(Optional.empty(), optional); }
	  

	@Test
	public void testUpdateProduct() {
		product.setPrice(1000);
		productRepository.save(product);
	    Product retvProduct = productRepository.findById(product.getProductId()).get();
	    assertEquals(1000, retvProduct.getPrice());
	}

	
	  @Test public void testSearch() { List<Product> retvProduct =
	  productRepository.search(product.getProductName());
	  assertTrue(retvProduct.size()>0); }
	 

	@Test
	public void testIsProductExists() {
		boolean retvProduct = productRepository.existsById(product.getProductId());
		assertTrue(retvProduct);
	}

}
	

