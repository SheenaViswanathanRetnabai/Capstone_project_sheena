package com.service;

import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.Optional;
import com.model.Cart;
import com.repository.CartRepository;



@SpringBootTest
public class CartServiceTest {
	
	@Autowired
	private CartRepository cartRepository;
	private Cart cart = new Cart();
	
	@Autowired
	private CartService cartService;
	

	@BeforeEach
	public void setUp() throws Exception {
		cart.setCartId(4005);		
		cart.setUsername("testuser22@gmail.com");
		cart.setProductId(1001);
		cart.setProductName("Laptop");		
		cart.setUnitAmount(1000);
		cart.setStatus(true);
		cart.setQuantity(2);
		cart.setTotalAmount(cart.getUnitAmount() *quantity);

		
		
		
		
		
	}

	@AfterEach
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetCart() {
		List<Cart> cartItem = (List<Cart>) cartService.getCarts();
		
		assertTrue(cartItem.size()>0);
	}

	@Test
	public void testGetCarts() {
		List<Cart> cartItem = (List<Cart>) cartService.getCarts();
		int cartItemId = cartItem.get(0).getCartId();
		Cart rtvCart = (Cart) cartService.getCart(cartItemId);
		assertEquals(cartItemId, rtvCart.getCartId());
	}

	@Test
	public void testSaveProductToCart() {
	
	  cartService.saveCart(cart);
	  Integer cartItemId = cart.getCartId();		
	  Optional<Cart> retvSavedProduct = cartRepository.findById(cartItemId);
	  assertEquals("Laptop", retvSavedProduct.get().getProductName());
		
	}
	int quantity=2;
	@Test

	public void testDeleteProductFromCart() {
		cart.setCartId(5005);		
		cart.setUsername("testuser44@gmail.com");
		cart.setProductId(1001);
		cart.setProductName("Laptop");		
		cart.setUnitAmount(1000);
		cart.setStatus(true);
		cart.setQuantity(2);
		cart.setTotalAmount(cart.getUnitAmount() *quantity);	
		 cartService.saveCart(cart);
        int cartItemId = cart.getCartId();
        cartService.deleteCart(cartItemId);
		Optional<Cart> retvCartProduct = cartRepository.findById(cartItemId);
    	assertEquals(Optional.empty(), retvCartProduct);
    	
    
	
	}
	

	

}


