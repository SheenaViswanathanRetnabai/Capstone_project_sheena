package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity

@Data
public class Cart {
	@Id
	private  int CartId;
	private  int productId;
	private  String productName;
	private	 int quantity;
	private int unitAmount;
	private  long totalAmount;
	private boolean status;
	private  int customerId;
	private String username;
	public Cart(int cartId, int productId, String productName, int quantity, int unitAmount, long totalAmount,
			boolean status, int customerId, String username) {
		super();
		CartId = cartId;
		this.productId = productId;
		this.productName = productName;
		this.quantity = quantity;
		this.unitAmount = unitAmount;
		this.totalAmount = totalAmount;
		this.status = status;
		this.customerId = customerId;
		this.username = username;
	}
	public Cart() {
		super();
	}
	

}
