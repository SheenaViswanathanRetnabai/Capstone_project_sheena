package com.model;



import javax.persistence.Entity;
import javax.persistence.Id;
import org.springframework.stereotype.Component;

import lombok.Data;
@Entity
@Data
@Component
public class UserRegistration {
	
	@Id
	private String username;
	private String customerName;
	private String password;
	private String repeatPassword;
	private String customerAddress;
	private long phone;
	private int billAmount;
	public UserRegistration(String username, String customerName, String password, String repeatPassword,
			String customerAddress, long phone, int billAmount) {
		super();
		this.username = username;
		this.customerName = customerName;
		this.password = password;
		this.repeatPassword = repeatPassword;
		this.customerAddress = customerAddress;
		this.phone = phone;
		this.billAmount = billAmount;
	}
	public UserRegistration() {
		super();
	}
	
	
	

}
