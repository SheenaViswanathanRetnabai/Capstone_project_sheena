package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.model.Product;

public interface ProductRepository  extends CrudRepository<Product, Integer>{
	 @Query(value = "SELECT p FROM Product p WHERE p.productId LIKE '%' || :keyword || '%'"
	            + " OR p.productName LIKE '%' || :keyword || '%'")
	            
	    public List<Product> search(@Param("keyword") String keyword);

}
