package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.model.Cart;



public interface CartRepository  extends CrudRepository<Cart, Integer>{
	 @Query(value = "SELECT p FROM Product p WHERE p.productId LIKE '%' || :keyword || '%'"
	            + " OR p.productName LIKE '%' || :keyword || '%'")
	            
	    public List<Cart> search(@Param("keyword") String keyword);

	public Object findByUsernameIs(String username);

	public List<Cart> getByUsername(String username);

	public Integer countByUsername(String username);
	
	@Query(value="SELECT sum(total_amount) from Cart  where username = ?1",nativeQuery=true)
    public Integer granttotal(String username);

	

	

}
