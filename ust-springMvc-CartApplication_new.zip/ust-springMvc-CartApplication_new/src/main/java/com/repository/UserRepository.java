package com.repository;



import org.springframework.data.repository.CrudRepository;

import com.model.UserRegistration;





public interface UserRepository  extends CrudRepository<UserRegistration, String>{

	UserRegistration findByUsername(String email);

	
	






	

	
	

	

	

}
