/*The Product Application includes the features to:
 * 
 *  1. A registration page--> if users do not have login credentials
 *  2. Login Page		  --> Allow the users to login if they have login credentials(Two type of user roles ROLE_ADMIN & ROLE_USER)
 *  3. Product Details
 *  	3.a. Add Product Details -ROLE_ADMIN
 *  	3.b. Edit Product Details -ROLE_ADMIN
 *  	3.c. Delete Product Details-ROLE_ADMIN
 *      3.d. List Product details -ROLE_ADMIN & ROLE_USER
 *      3.e  Search Products by using keywords. -ROLE_ADMIN & ROLE_USER
 *  4.Customer details
 *  	4.a. Add  Customer Details -ROLE_USER
 *  5.Cart
 *      5.a User can add max 10 products to cart at a time.
 *      5.b The cart can be persisted for his next login
 *      5.c If all the products are removed, cart should not be displayed.
 *   6. Send the cart status as email.
 * 
 * 
 * 
*/

package com.controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.model.Cart;
import com.model.Customer;
import com.model.Product;
import com.model.UserRegistration;
import com.service.CartService;
import com.service.EmailService;
import com.service.ProductService;
import com.service.RegistrationService;



@Controller
public class ProductController {
	
	@Autowired
	ProductService productService;
	@Autowired
	CartService cartService;
	@Autowired
	RegistrationService registrationService;
	@Autowired
	MailSender mailSender;
	@Autowired
    private EmailService emailService;
	public Product product;
	public UserRegistration userRegistration=new UserRegistration();
	public Cart cart=new Cart();
	public  int cartitemCount;
	public String email = null;
	public String userName=null;
	public String displayName=null;
	org.jboss.logging.Logger logger= LoggerFactory.logger(ProductController.class);

	
// New User Registration form
		
		
		@RequestMapping(value="/register",method=RequestMethod.GET)
		public ModelAndView register()
		{
			return new ModelAndView("registration","user",new UserRegistration());
		}
		
//setting the new user registration details into the database
		
		@Autowired
		JdbcUserDetailsManager jdbcUserDetailsManager;
		@RequestMapping(value="/register",method=RequestMethod.POST)
		public ModelAndView registerUser(@ModelAttribute("user") UserRegistration userregistration)
		{
			List<GrantedAuthority> authorities=new ArrayList<GrantedAuthority>();
			if(registrationService.IsUserexists(userregistration.getUsername()))
			{
				return new ModelAndView("login","message","You are Already registred.Please login to proceed");
			}
			else
			{
			registrationService.saveUser(userregistration);
			authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
			//authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
			User user=new User(userregistration.getUsername(),userregistration.getPassword(),authorities);
			jdbcUserDetailsManager.createUser(user);
		
			logger.info("user registration............."+userregistration);
			
			
			return new ModelAndView("login","message","You are successfully registered.Please login to proceed");
			}
		}
		
//List the product details in cart		

		@RequestMapping("/cartlisting")
		public ModelAndView listcarts() 
		{
			//get the login User name
			
			Integer cartitemCount=null;
			Integer granttotal=null;
			 getDisplayName(); 
			
			
			List<Cart> listItems = cartService.getByName(email);
			cartitemCount=cartService.countByName(email);
  		     granttotal=cartService.granttotal(email);
					System.out.println("grant total****************"+cartitemCount);
			   ModelAndView map = new ModelAndView("cart"); 
			   map.addObject("listItems", listItems);
			   map.addObject("displayName",displayName);
			   map.addObject("cartitemCount",cartitemCount);
			   if(cartitemCount!=null)
			   {
			   map.addObject("granttotal",granttotal);
			   }
			   else
			   {
				   map.addObject("granttotal","0");
				   map.addObject("message","No item added to cart"); 
			   }
			   
			   		   
			   return map;
			   
		}
		
//get the User Name to display using email
		
			private String getDisplayName() {
				Object principal=SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				
				
				
				if(principal instanceof UserDetails)
				{
					email=((UserDetails)principal).getUsername();
					userRegistration=registrationService.getuserName(email);
					displayName=userRegistration.getCustomerName();
					logger.info("displayname$$$$$$$$$$$$$$$$$$"+displayName);
					
				}
				return displayName;
	
               }

			@RequestMapping("/cart")
					public ModelAndView addToCart(@RequestParam int productId,Model model) 
		{
				
			
// add product details into the cart
				
				   int quantity=1;
				   getDisplayName(); 
				   	 

					   
				   product= productService.getProduct(productId);
				  
				   
				   if(cartService.countByName(email)<10 && product.getQuantityOnHand()!=0 )
				   {
				   cart.setProductId(product.getProductId());
				   cart.setProductName(product.getProductName());
				   cart.setStatus(true);
				   cart.setQuantity(quantity);
				   cart.setUnitAmount(product.getPrice());
				   cart.setTotalAmount(quantity*product.getPrice());
				   cart.setUsername(email);
				   cartService.saveCart(cart);
				   cartitemCount=cartService.countByName(email);
				   System.out.println("***************************in /cart  itemcount"+cartitemCount);
				  
				 if(product.getQuantityOnHand()!=0)
				 {
					   int newQuantity=product.getQuantityOnHand()-1;
					   product.setQuantityOnHand(newQuantity);
					   productService.saveProduct(product);
					  
					   model.addAttribute("message", "** Product added to cart");
				 }
				   }
				   else if(product.getQuantityOnHand()==0)
				   {
					   model.addAttribute("message", "** Item not in Stock");  
				   }
				   
				   else
				   {
					  
					   model.addAttribute("message", "** You can not add more than 10 products to cart");
					   logger.info("can not add more than 10 products to cart");
				   }
				   List<Product> listProducts =  productService.getProducts();
				    ModelAndView map = new ModelAndView("index");
				    map.addObject("listProducts", listProducts);
				    map.addObject("displayName",displayName);
				    map.addObject("cartitemCount",cartitemCount);
				    System.out.println(listProducts);
				    return map;
				   
				  
				
				          
				
		}
			
		
			
			
// Delete product from the cart
			
			
			@RequestMapping("/remove")
			public ModelAndView deleteItem(@RequestParam int cartId) {
				 getDisplayName(); 

						
						Integer granttotal=null;

			
				 ModelAndView map = new ModelAndView("cart");
				 
				 
				 cart=cartService.getCart(cartId);
				    cartService.deleteCart(cartId);
				    product=productService.getProduct(cart.getProductId());
				   
				    product.setQuantityOnHand(product.getQuantityOnHand()+1);
				    
					productService.updateProduct(product);
				 
				 
				 
			  //  cartService.deleteCart(cartId);
				
			    
			    
			    List<Cart> listItems = cartService.getByName(email);
			    granttotal=cartService.granttotal(email); 
			    if(listItems!=null && granttotal!=null)
			    {
			      	    
				   map.addObject("listItems", listItems);
				   map.addObject("displayName",displayName);
				   map.addObject("granttotal",granttotal);
				   map.addObject("cartitemCount",cartitemCount);
			    }
			    else
			    {
			    	map.addObject("granttotal","0");
			    	map.addObject("message","No item added to cart");
			    	map.addObject("cartitemCount","0");
			    }
			    logger.info("cart items#####################"+listItems);		   
				   return map;
			}
			
			
		
				

			
			@RequestMapping(value="/login",method=RequestMethod.GET)
			public String login(Model model,String error,String logout)throws AddressException, MessagingException, IOException
			{
				
				if(error!=null)
				{
					model.addAttribute("errMsg", "Your username or password is incorrect");
				}
				else
				{
					model.addAttribute("msg", "You have been successfully logged out");
				}
				return "login";
			
				
			}
			
		
		
	
		
		
// Add new Product details  product Details

	@RequestMapping("/addProduct")
	public String addProduct(){
		return "addProduct";
		
	}

//Add customer details 

	@RequestMapping("/addCustomer")
	public ModelAndView addCustomer(){
		return new ModelAndView("addCustomer","command",new Customer());
		
	}
	
	
	
//Save customer details

		@RequestMapping("/saveCustomer")
		public String saveCustomer(UserRegistration userRegistration){
			if(registrationService.IsUserexists(email))
			 {
				 return "failed";	
			 }
			
			 else {
			 
			registrationService.saveUser(userRegistration);
					return "success";	 
			 }
		}
			
//save product details

	@RequestMapping("/saveProduct")
	public String saveProduct(Product product){
		 if(productService.IsProductexists(product.getProductId()))
		 {
			 return "failed";	
		 }
		 else
		 {
			 productService.saveProduct(product);
				return "success";	 
		 }
		
	}	
// Edit Product details
	
	@RequestMapping("/editProduct")
	public String editProduct(Product product){
		 if(productService.IsProductexists(product.getProductId()))
		 {
			 productService.saveProduct(product);
				return "success";
				
		 }
		 else
		 {
			 return "failed";	 
		 }
		
	}	

	
	@RequestMapping("/edit")
	public ModelAndView editProduct(@RequestParam int productId) {
		 ModelAndView model = new ModelAndView("editProduct");
	    Product product = productService.getProduct(productId);
	    model.addObject("product", product);
    return model;
	}

	
// Delete the Product details
	@RequestMapping("/delete")
	public String deleteCustomerForm(@RequestParam int productId) {
	    productService.deleteProduct(productId);
	    return "successdelete";       
	}
	
	
	

//List the product details
//	
	@RequestMapping("/index")

		public ModelAndView listProducts1()  
	{
		 getDisplayName(); 
	
				
	   
			    List<Product> listProducts =  productService.getProducts();
			    cartitemCount=cartService.countByName(email);
			    ModelAndView map = new ModelAndView("index");
			    map.addObject("listProducts", listProducts);
			    map.addObject("displayName",displayName);
			    map.addObject("cartitemCount",cartitemCount);
			    logger.info("Product List:"+listProducts);
			    return map;
		
	}
	
	
	
	@RequestMapping("/")
			public ModelAndView listProducts() throws AddressException, MessagingException, IOException
	{
		 getDisplayName(); 

		
		
		    List<Product> listProducts =  productService.getProducts();
		    cartitemCount=cartService.countByName(email);
		    ModelAndView map = new ModelAndView("index");
		    map.addObject("listProducts", listProducts);
		    map.addObject("displayName",displayName);
		    map.addObject("cartitemCount",cartitemCount);
		    logger.info("list of products"+listProducts);
// sent the email service to sent email	       
		    	emailService.sendmail( email);
		   
		    return map;
		   
		}
	
	
	
//Search by ProductId or ProductName
	@RequestMapping("/searchresult")
	public ModelAndView search(@RequestParam String keyword) {
	    List<Product> result = productService.search(keyword);
	    ModelAndView mav = new ModelAndView("searchresult");
	    mav.addObject("result", result);
	 
	    return mav;    
	}
	

	}

