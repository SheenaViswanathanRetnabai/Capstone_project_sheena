package com.security;



import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
	
//JDBC authentication	
	
@Autowired
DataSource dataSource;
@Autowired
public void configAuthentication(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception
{
	authenticationManagerBuilder.jdbcAuthentication().dataSource(dataSource);
}

//Authorization
@Override
protected void configure(HttpSecurity http) throws Exception
{
	http.authorizeRequests()
	//.antMatchers("/").permitAll()
	.antMatchers("/register").permitAll()
	.antMatchers("/index").hasAnyRole("USER","ADMIN")
	.antMatchers("/addProduct").hasAnyRole("ADMIN")
	.antMatchers("/addCustomer").hasAnyRole("ADMIN")
	.antMatchers("/updateProduct").hasAnyRole("ADMIN")
	.antMatchers("/edit").hasAnyRole("ADMIN")
	.antMatchers("/delete").hasAnyRole("ADMIN")
	.antMatchers("/listProduct").hasAnyRole("USER","ADMIN")
	.anyRequest().authenticated().and().formLogin().loginPage("/login").permitAll();
	
	//cross site request frogery
	http.csrf().disable();
}



@Bean
public PasswordEncoder passwordEncoder()
{
return NoOpPasswordEncoder.getInstance();

}
@Bean
public JdbcUserDetailsManager jdbcUserDetailsManager()
{
	JdbcUserDetailsManager jdbcUserDetailsManager= new JdbcUserDetailsManager();
	jdbcUserDetailsManager.setDataSource(dataSource);
	return jdbcUserDetailsManager;
	
}
}
