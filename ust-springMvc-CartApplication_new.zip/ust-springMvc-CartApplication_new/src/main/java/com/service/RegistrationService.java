package com.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.UserRegistration;
import com.repository.UserRepository;



@ Service
@Transactional
public class RegistrationService {
	@Autowired
	UserRepository userrepository;

	
	public void saveUser(UserRegistration user)
	{
		userrepository.save(user);
	}



public UserRegistration getuserName(String email)
{
	return userrepository.findByUsername(email);
	
}
public boolean IsUserexists(String email)
{
	return userrepository.existsById(email);
}

}
