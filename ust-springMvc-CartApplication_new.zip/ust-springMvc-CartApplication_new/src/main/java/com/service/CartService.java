package com.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Cart;
import com.repository.CartRepository;




@ Service
@Transactional
public class CartService {
	@Autowired
	CartRepository cartrepository;
	
	public List<Cart>getCarts()
	{
		return (List<Cart>)cartrepository.findAll();
	}
	public void saveCart(Cart cart)
	{
		cartrepository.save(cart);
	}
	public Cart getCart(int cartId)
	{
		Optional<Cart> cart=cartrepository.findById(cartId);
		return cart.get();
	}
	
	public void deleteCart(int cartId)
	{
		
		cartrepository.deleteById(cartId);
	}
	
	public void updateCart(Cart cart)
	{
		cartrepository.save(cart);
	}
	//check whether the particular cart exists or not
	public boolean IsCartexists(int cartId)
	{
		return cartrepository.existsById(cartId);
	}
	
	public List<Cart> search(String keyword) {
	    return cartrepository.search(keyword);
	}
	

public long itemcount() {
    return cartrepository.count();
}
public Integer countByName(String username)
{
	return cartrepository.countByUsername(username);
}
public boolean checkIfUserExists(String username)
{
	return cartrepository.findByUsernameIs(username)!=null?true:false;
}
public List<Cart> getByName(String username)
{
	return cartrepository.getByUsername(username);
}

public Integer granttotal(String username) {
    return cartrepository.granttotal( username);
   
}

}
