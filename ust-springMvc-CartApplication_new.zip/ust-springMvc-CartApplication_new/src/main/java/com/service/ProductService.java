package com.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Product;
import com.repository.ProductRepository;



@ Service
@Transactional
public class ProductService {
	@Autowired
	ProductRepository productrepository;
	
	public List<Product>getProducts()
	{
		return (List<Product>)productrepository.findAll();
	}
	public void saveProduct(Product product)
	{
		productrepository.save(product);
	}
	public Product getProduct(int productId)
	{
		Optional<Product> product=productrepository.findById(productId);
		return product.get();
	}
	
	public void deleteProduct(int productId)
	{
		
		productrepository.deleteById(productId);
	}
	
	public void updateProduct(Product product)
	{
		productrepository.save(product);
	}
	//check whether the particular product exists or not
	public boolean IsProductexists(int productId)
	{
		return productrepository.existsById(productId);
	}
	
	public List<Product> search(String keyword) {
	    return productrepository.search(keyword);
	}
}
