package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Customer;
import com.repository.CustomerRepository;




@ Service
public class CustomerService {
	@Autowired
	CustomerRepository Customerrepository;
	
	public List<Customer>getCustomers()
	{
		return (List<Customer>)Customerrepository.findAll();
	}
	public void saveCustomer(Customer Customer)
	{
		Customerrepository.save(Customer);
	}
	public Customer getCustomer(Integer CustomerId)
	{
		Optional<Customer> Customer=Customerrepository.findById(CustomerId);
		return Customer.get();
	}
	
	public void deleteCustomer(Integer CustomerId)
	{
		
		Customerrepository.deleteById(CustomerId);
	}
	
	public void updateCustomer(Customer Customer)
	{
		Customerrepository.save(Customer);
	}
	//check whether the particular Customer exists or not
	public boolean IsCustomerexists(int CustomerId)
	{
		return Customerrepository.existsById(CustomerId);
	}
	public Customer getuserName(String email)
	{
		return Customerrepository.findByEmail(email);
		
	}
	
	
}
